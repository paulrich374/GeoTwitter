These are the photos on http://www.flickr.com/photos/bennett1666/.

These are the photos I use in my tutorial on webdesign.tutsplus.com/

I did not take any of these pictures! 

The name of each photographer is identified in each file name. All of these pictures were released under the creative commons 'by' licence ( www.flickr.com/creativecommons/by-2.0/ )